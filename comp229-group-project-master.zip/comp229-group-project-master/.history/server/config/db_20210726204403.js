/* Database Connection URI */
module.exports = 
{
    "URI": "mongodb+srv://shahin:QY6mxBfoQ6RLrEFv@mongodbserver.me3cw.mongodb.net/survey_db?retryWrites=true&w=majority"
}