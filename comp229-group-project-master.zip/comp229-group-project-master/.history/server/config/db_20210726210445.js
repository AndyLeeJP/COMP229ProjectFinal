/* Database Connection URI */
module.exports = 
{
    "URI": "mongodb+srv://romviki:VLNUnFgaf3Kq33JN@cluster0.sft3q.mongodb.net/surveydb?retryWrites=true&w=majority"
}